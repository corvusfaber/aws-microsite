import json
import boto3

s3 = boto3.client('s3')

def handler(event, context):
    for record in event['Records']:

        # Parse the body of the SQS message
        body = json.loads(record['body'])
        #print(body['Records'])
        for item in body['Records']:
            bucket = item['s3']['bucket']
            print(bucket)

    return {
        'statusCode': 200,
        'body': json.dumps('File processed successfully!')
    }
